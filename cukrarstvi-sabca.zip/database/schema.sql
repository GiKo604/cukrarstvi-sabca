-- Cukrářství Šábca - Databázové schéma
-- Verze: 1.0
-- Datum: Říjen 2025

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- Vytvoření databáze
CREATE DATABASE IF NOT EXISTS `cukrarstvi_sabca` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `cukrarstvi_sabca`;

-- Tabulka pro stránky
CREATE TABLE `stranky` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nazev` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL UNIQUE,
  `obsah` longtext,
  `meta_popis` text,
  `meta_klicova_slova` text,
  `aktivni` tinyint(1) DEFAULT 1,
  `datum_vytvoreni` datetime DEFAULT CURRENT_TIMESTAMP,
  `datum_upravy` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`),
  KEY `aktivni` (`aktivni`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabulka pro kategorie receptů
CREATE TABLE `kategorie_receptu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nazev` varchar(100) NOT NULL,
  `popis` text,
  `barva` varchar(7) DEFAULT '#ff6b35',
  `poradi` int(11) DEFAULT 0,
  `aktivni` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `aktivni` (`aktivni`),
  KEY `poradi` (`poradi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabulka pro recepty
CREATE TABLE `recepty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nazev` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL UNIQUE,
  `popis` text,
  `ingredience` text,
  `postup` text,
  `cas_pripravy` int(11),
  `pocet_porci` int(11),
  `obtiznost` enum('snadná','střední','těžká') DEFAULT 'snadná',
  `kategorie_id` int(11),
  `hlavni_obrazek` varchar(255),
  `aktivni` tinyint(1) DEFAULT 1,
  `datum_vytvoreni` datetime DEFAULT CURRENT_TIMESTAMP,
  `datum_upravy` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`),
  KEY `kategorie_id` (`kategorie_id`),
  KEY `aktivni` (`aktivni`),
  FOREIGN KEY (`kategorie_id`) REFERENCES `kategorie_receptu` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabulka pro dodatečné obrázky receptů
CREATE TABLE `obrazky_receptu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recept_id` int(11) NOT NULL,
  `nazev_souboru` varchar(255) NOT NULL,
  `puvodni_nazev` varchar(255),
  `alt_text` varchar(255),
  `poradi` int(11) DEFAULT 0,
  `datum_nahrani` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `recept_id` (`recept_id`),
  KEY `poradi` (`poradi`),
  FOREIGN KEY (`recept_id`) REFERENCES `recepty` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabulka pro kategorie galerie
CREATE TABLE `kategorie_galerie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nazev` varchar(100) NOT NULL,
  `popis` text,
  `barva` varchar(7) DEFAULT '#3498db',
  `poradi` int(11) DEFAULT 0,
  `aktivni` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `aktivni` (`aktivni`),
  KEY `poradi` (`poradi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabulka pro galerii
CREATE TABLE `galerie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nazev` varchar(200),
  `nazev_souboru` varchar(255) NOT NULL,
  `alt_text` varchar(255),
  `popis` text,
  `kategorie` int(11),
  `poradi` int(11) DEFAULT 0,
  `aktivni` tinyint(1) DEFAULT 1,
  `datum_nahrany` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `kategorie` (`kategorie`),
  KEY `aktivni` (`aktivni`),
  KEY `poradi` (`poradi`),
  FOREIGN KEY (`kategorie`) REFERENCES `kategorie_galerie` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabulka pro kontaktní zprávy
CREATE TABLE `kontaktni_zpravy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jmeno` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `telefon` varchar(20),
  `zprava` text NOT NULL,
  `stav` enum('nova','prectena','odpovezena','archivovana') DEFAULT 'nova',
  `poznamky` text,
  `datum_odeslani` datetime DEFAULT CURRENT_TIMESTAMP,
  `datum_precteni` datetime NULL,
  PRIMARY KEY (`id`),
  KEY `stav` (`stav`),
  KEY `datum_odeslani` (`datum_odeslani`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vložení výchozích kategorií receptů
INSERT INTO `kategorie_receptu` (`nazev`, `popis`, `barva`, `poradi`, `aktivni`) VALUES
('Dorty', 'Slavnostní dorty a koláče', '#e91e63', 1, 1),
('Cukroví', 'Drobné pečivo a sladkosti', '#ff9800', 2, 1),
('Chleby', 'Pečivo a chleby', '#8bc34a', 3, 1),
('Sezónní', 'Sezónní speciality', '#9c27b0', 4, 1);

-- Vložení výchozích kategorií galerie
INSERT INTO `kategorie_galerie` (`nazev`, `popis`, `barva`, `poradi`, `aktivni`) VALUES
('Dorty', 'Fotografie dortů a velkých koláčů', '#e91e63', 1, 1),
('Cukroví', 'Fotografie drobného pečiva', '#ff9800', 2, 1),
('Cukrárna', 'Fotografie z provozu cukrárny', '#2196f3', 3, 1),
('Akce', 'Fotografie z akcí a oslav', '#4caf50', 4, 1);

-- Vložení výchozích stránek
INSERT INTO `stranky` (`nazev`, `slug`, `obsah`, `aktivni`) VALUES
('Domů', 'domu', '<h1>Vítejte v našem cukrářství</h1><p>Nabízíme nejlepší cukrářské výrobky v okolí.</p>', 1),
('O nás', 'o-nas', '<h1>O našem cukrářství</h1><p>Více než 20 let zkušeností v oboru.</p>', 1),
('Kontakt', 'kontakt', '<h1>Kontaktujte nás</h1><p>Rádi vám poradíme s výběrem.</p>', 1);

COMMIT;