<?php
// Nástroj pro vytvoření chybějících thumbnailů

require_once '../config/databaze-config.php';

echo "<h2>Generování chybějících thumbnailů</h2>\n";

// Najít všechny obrázky v uploads/recepty
$receptyDir = UPLOAD_RECEPTY_DIR;
$thumbnailsDir = UPLOAD_THUMBNAILS_DIR;

if (!is_dir($receptyDir)) {
    echo "<p style='color: red;'>Složka uploads/recepty neexistuje!</p>";
    exit;
}

if (!is_dir($thumbnailsDir)) {
    echo "<p>Vytváří se složka pro thumbnaily...</p>";
    mkdir($thumbnailsDir, 0755, true);
}

$files = scandir($receptyDir);
$created = 0;
$errors = 0;

foreach ($files as $file) {
    if ($file === '.' || $file === '..') continue;
    
    $sourcePath = $receptyDir . '/' . $file;
    $thumbnailPath = $thumbnailsDir . '/thumb_' . $file;
    
    // Pouze obrazové soubory
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
        continue;
    }
    
    echo "<p>Zpracovávám: $file</p>";
    
    // Pokud thumbnail už existuje, přeskočit
    if (file_exists($thumbnailPath)) {
        echo "<p style='color: blue;'>  - Thumbnail už existuje</p>";
        continue;
    }
    
    try {
        if (createThumbnail($sourcePath, $thumbnailPath)) {
            echo "<p style='color: green;'>  ✓ Thumbnail vytvořen: thumb_$file</p>";
            $created++;
        } else {
            echo "<p style='color: red;'>  ✗ Chyba při vytváření thumbnail</p>";
            $errors++;
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>  ✗ Chyba: " . $e->getMessage() . "</p>";
        $errors++;
    }
}

echo "<hr>";
echo "<p><strong>Dokončeno!</strong></p>";
echo "<p>Vytvořeno thumbnailů: $created</p>";
echo "<p>Chyb: $errors</p>";

// Také zkontrolujme galerii
echo "<h3>Kontrola galerie</h3>";
$galerieDir = UPLOAD_GALERIE_DIR;
if (is_dir($galerieDir)) {
    $galerieFiles = scandir($galerieDir);
    foreach ($galerieFiles as $file) {
        if ($file === '.' || $file === '..') continue;
        
        $sourcePath = $galerieDir . '/' . $file;
        $thumbnailPath = $thumbnailsDir . '/thumb_' . $file;
        
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            continue;
        }
        
        if (!file_exists($thumbnailPath)) {
            echo "<p>Vytváří se thumbnail pro galerii: $file</p>";
            try {
                if (createThumbnail($sourcePath, $thumbnailPath)) {
                    echo "<p style='color: green;'>  ✓ Thumbnail vytvořen: thumb_$file</p>";
                } else {
                    echo "<p style='color: red;'>  ✗ Chyba při vytváření thumbnail</p>";
                }
            } catch (Exception $e) {
                echo "<p style='color: red;'>  ✗ Chyba: " . $e->getMessage() . "</p>";
            }
        }
    }
}
?>