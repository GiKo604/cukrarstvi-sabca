-- Active: 1759388908017@@127.0.0.1@3306@cukrarstvi_sabca
-- Databázové schéma pro Sabčino zázračné cukrářství
-- Vytvořte novou databázi před spuštěním tohoto skriptu

-- Použití databáze
-- CREATE DATABASE cukrarstvi_sabca CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;
-- USE cukrarstvi_sabca;

-- Tabulka pro stránky webu

CREATE DATABASE IF NOT EXISTS cukrarstvi_sabca CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;
CREATE TABLE stranky (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(50) NOT NULL UNIQUE,
    nazev VARCHAR(100) NOT NULL,
    menu_nazev VARCHAR(50) NOT NULL,
    obsah LONGTEXT NOT NULL,
    meta_popis TEXT,
    meta_klicova_slova TEXT,
    aktivni BOOLEAN DEFAULT TRUE,
    poradi INT DEFAULT 0,
    datum_vytvoreni TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    datum_upravy TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_slug (slug),
    INDEX idx_aktivni (aktivni),
    INDEX idx_poradi (poradi)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Tabulka pro kategorie receptů
CREATE TABLE kategorie_receptu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nazev VARCHAR(100) NOT NULL,
    popis TEXT,
    barva VARCHAR(7) DEFAULT '#834912',
    poradi INT DEFAULT 0,
    aktivni BOOLEAN DEFAULT TRUE,
    datum_vytvoreni TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_aktivni (aktivni),
    INDEX idx_poradi (poradi)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Tabulka pro recepty
CREATE TABLE recepty (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nazev VARCHAR(150) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    popis TEXT,
    ingredience LONGTEXT NOT NULL,
    postup LONGTEXT NOT NULL,
    cas_pripravy INT DEFAULT 0, -- v minutách
    pocet_porci INT DEFAULT 1,
    obtiznost ENUM('snadná', 'střední', 'těžká') DEFAULT 'střední',
    kategorie_id INT,
    hlavni_obrazek VARCHAR(255),
    meta_popis TEXT,
    aktivni BOOLEAN DEFAULT TRUE,
    poradi INT DEFAULT 0,
    datum_vytvoreni TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    datum_upravy TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (kategorie_id) REFERENCES kategorie_receptu(id) ON DELETE SET NULL,
    INDEX idx_slug (slug),
    INDEX idx_aktivni (aktivni),
    INDEX idx_kategorie (kategorie_id),
    INDEX idx_poradi (poradi)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Tabulka pro obrázky receptů
CREATE TABLE obrazky_receptu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recept_id INT NOT NULL,
    nazev_souboru VARCHAR(255) NOT NULL,
    puvodni_nazev VARCHAR(255),
    alt_text VARCHAR(255),
    popis TEXT,
    poradi INT DEFAULT 0,
    hlavni BOOLEAN DEFAULT FALSE,
    datum_nahrany TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (recept_id) REFERENCES recepty(id) ON DELETE CASCADE,
    INDEX idx_recept (recept_id),
    INDEX idx_poradi (poradi),
    INDEX idx_hlavni (hlavni)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Tabulka pro galerii obrázků
CREATE TABLE galerie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nazev VARCHAR(150) NOT NULL,
    nazev_souboru VARCHAR(255) NOT NULL,
    alt_text VARCHAR(255),
    popis TEXT,
    kategorie VARCHAR(50),
    poradi INT DEFAULT 0,
    aktivni BOOLEAN DEFAULT TRUE,
    datum_nahrany TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_kategorie (kategorie),
    INDEX idx_aktivni (aktivni),
    INDEX idx_poradi (poradi)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Tabulka pro kontaktní zprávy (přenos ze souborů)
CREATE TABLE kontaktni_zpravy (
    id INT AUTO_INCREMENT PRIMARY KEY,
    jmeno VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    zprava LONGTEXT NOT NULL,
    ip_adresa VARCHAR(45),
    stav ENUM('nová', 'přečtená', 'odpovězená', 'spam') DEFAULT 'nová',
    poznamky TEXT,
    datum_odeslani TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    datum_zpracovani TIMESTAMP NULL,
    
    INDEX idx_stav (stav),
    INDEX idx_datum (datum_odeslani),
    INDEX idx_email (email)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Tabulka pro uživatele administrace
CREATE TABLE admin_uzivatele (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uzivatelske_jmeno VARCHAR(50) NOT NULL UNIQUE,
    heslo VARCHAR(255) NOT NULL,
    jmeno VARCHAR(100),
    email VARCHAR(150),
    role ENUM('admin', 'editor') DEFAULT 'editor',
    aktivni BOOLEAN DEFAULT TRUE,
    posledni_prihlaseni TIMESTAMP NULL,
    datum_vytvoreni TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_uzivatelske_jmeno (uzivatelske_jmeno),
    INDEX idx_aktivni (aktivni)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Základní data pro stránky
INSERT INTO stranky (slug, nazev, menu_nazev, obsah, poradi) VALUES
('domu', 'Sabčino zázračné cukrářství', 'Domů', 
'<main>
    <p>Vítejte v našem rodinném cukrářství, kde tradice potkává inovaci! Již více než 20 let připravujeme nejlahodnější dorty, zákusky a sladkosti z těch nejkvalitnějších surovin.</p>
    
    <div class="middle-img">
        <a href="index.php?id-stranky=recepty" title="Čokoládový dort">
            <img src="img/dort1.jpg" alt="Čokoládový dort">
        </a>
        <a href="index.php?id-stranky=recepty" title="Ovocný koláč">
            <img src="img/kolac1.jpg" alt="Ovocný koláč">
        </a>
        <a href="index.php?id-stranky=recepty" title="Cupcakes">
            <img src="img/cupcake1.jpg" alt="Cupcakes">
        </a>
        <a href="index.php?id-stranky=recepty" title="Svatební dort">
            <img src="img/dort2.jpg" alt="Svatební dort">
        </a>
    </div>
    
    <p>Naše cukrářství se specializuje na výrobu svatebních dortů, narozeninových překvapení a dalších sladkých radostí. Každý kousek pečeme s láskou a věnujeme mu maximální pozornost.</p>
</main>', 10),

('galerie', 'Galerie našich výtvorů', 'Galerie', 
'<main>
    <div class="galerie-container">
        <!-- Obsah galerie se načítá dynamicky z databáze -->
        <p>Galerie se načítá...</p>
    </div>
</main>', 20),

('recepty', 'Naše oblíbené recepty', 'Recepty', 
'<main>
    <div class="recepty-container">
        <!-- Obsah receptů se načítá dynamicky z databáze -->
        <p>Recepty se načítají...</p>
    </div>
</main>', 30),

('kontakt', 'Kontakt', 'Kontakt', '', 40);

-- Základní kategorie receptů
INSERT INTO kategorie_receptu (nazev, popis, barva, poradi) VALUES
('Dorty a torty', 'Slavnostní dorty pro všechny příležitosti', '#8B4513', 10),
('Cupcakes a muffiny', 'Malé sladké radosti', '#D2691E', 20),
('Sušenky a cukroví', 'Tradiční i moderní sušenky', '#CD853F', 30),
('Dezerty a speciality', 'Výjimečné dezerty a sezónní speciality', '#A0522D', 40);

-- Ukázkové recepty (převedené z původního HTML)
INSERT INTO recepty (nazev, slug, popis, ingredience, postup, cas_pripravy, pocet_porci, obtiznost, kategorie_id) VALUES
('Čokoládový dort', 'cokoladovy-dort', 
'Luxusní čokoládový dort s ganache krémem', 
'<ul>
<li>200g tmavé čokolády</li>
<li>150g másla</li>
<li>3 vejce</li>
<li>100g cukru</li>
<li>50g mouky</li>
<li>200ml smetany na šlehání</li>
</ul>',
'<ol>
<li>Rozpusťte čokoládu s máslem</li>
<li>Ušlehejte vejce s cukrem</li>
<li>Vmíchejte čokoládu a mouku</li>
<li>Pečte 25 minut při 180°C</li>
<li>Připravte ganache ze smetany a čokolády</li>
<li>Dort potřete krémem</li>
</ol>',
90, 8, 'střední', 1),

('Vanilkové cupcakes', 'vanilkove-cupcakes',
'Jemné vanilkové cupcakes s krémem',
'<ul>
<li>150g mouky</li>
<li>100g cukru</li>
<li>2 vejce</li>
<li>80ml oleje</li>
<li>1 vanilkový lusk</li>
<li>200g másla na krém</li>
</ul>',
'<ol>
<li>Smíchejte suché ingredience</li>
<li>Přidejte mokré ingredience</li>
<li>Pečte 18 minut při 170°C</li>
<li>Připravte vanilkový krém</li>
<li>Dozdobte podle chuti</li>
</ol>',
45, 12, 'snadná', 2);

-- Výchozí admin uživatel (heslo: admin123)
INSERT INTO admin_uzivatele (uzivatelske_jmeno, heslo, jmeno, email, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrátor', 'admin@sabcinecukrarstvi.cz', 'admin');

-- Trigger pro automatické nastavení hlavního obrázku receptu
DELIMITER //
CREATE TRIGGER set_hlavni_obrazek 
AFTER INSERT ON obrazky_receptu
FOR EACH ROW
BEGIN
    IF NEW.hlavni = TRUE THEN
        UPDATE obrazky_receptu 
        SET hlavni = FALSE 
        WHERE recept_id = NEW.recept_id AND id != NEW.id;
        
        UPDATE recepty 
        SET hlavni_obrazek = NEW.nazev_souboru 
        WHERE id = NEW.recept_id;
    END IF;
END//
DELIMITER ;

-- Zobrazení pro jednodušší dotazy
CREATE VIEW recepty_s_kategorii AS
SELECT 
    r.id,
    r.nazev,
    r.slug,
    r.popis,
    r.cas_pripravy,
    r.pocet_porci,
    r.obtiznost,
    r.hlavni_obrazek,
    r.aktivni,
    k.nazev as kategorie_nazev,
    k.barva as kategorie_barva
FROM recepty r
LEFT JOIN kategorie_receptu k ON r.kategorie_id = k.id
WHERE r.aktivni = TRUE
ORDER BY r.poradi, r.nazev;

-- Tabulka pro kategorie galerie
CREATE TABLE kategorie_galerie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nazev VARCHAR(100) NOT NULL,
    popis TEXT,
    barva VARCHAR(7) DEFAULT '#3498db',
    poradi INT DEFAULT 0,
    aktivni BOOLEAN DEFAULT TRUE,
    datum_vytvoreni TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_aktivni (aktivni),
    INDEX idx_poradi (poradi)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci;

-- Výchozí kategorie galerie
INSERT INTO kategorie_galerie (nazev, popis, barva, poradi, aktivni) VALUES
('Dorty a Torty', 'Narozeninové dorty, svatební torty a další slavnostní dorty', '#e74c3c', 1, TRUE),
('Cupcakes a Muffiny', 'Malé dortíky a muffiny pro každou příležitost', '#f39c12', 2, TRUE),
('Sušenky a Cukroví', 'Křehké sušenky, perníčky a vánoční cukroví', '#27ae60', 3, TRUE),
('Dezerty a Speciality', 'Trifle, tiramisu a další speciality', '#9b59b6', 4, TRUE);